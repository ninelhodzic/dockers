This is the jWebSocket Server's default cache folder.
You can use a different folder for the cache repository 
e.g. by updating the ehcache.xml configuration file in the ${JWEBSOCKET_HOME}/conf folder.